vti_encoding:SR|utf8-nl
vti_author:SR|HAHA-PC\\HAHA
vti_modifiedby:SR|HAHA-PC\\HAHA
vti_timelastmodified:TR|27 Sep 2015 11:01:40 -0000
vti_timecreated:TR|27 Sep 2015 11:01:40 -0000
vti_cacheddtm:TX|27 Sep 2015 11:01:40 -0000
vti_filesize:IR|3580
vti_extenderversion:SR|12.0.0.0
vti_backlinkinfo:VX|content/TeachAnime/Teach_content/fourier/fourier.html
